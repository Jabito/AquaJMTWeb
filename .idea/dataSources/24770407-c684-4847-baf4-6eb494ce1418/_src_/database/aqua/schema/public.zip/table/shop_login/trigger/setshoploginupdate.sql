CREATE TRIGGER setshoploginupdate
BEFORE UPDATE ON shop_login
FOR EACH ROW EXECUTE PROCEDURE setupdateoncolumn()