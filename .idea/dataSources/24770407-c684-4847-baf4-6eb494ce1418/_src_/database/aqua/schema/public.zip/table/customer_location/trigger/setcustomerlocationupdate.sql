CREATE TRIGGER setcustomerlocationupdate
BEFORE UPDATE ON customer_location
FOR EACH ROW EXECUTE PROCEDURE setupdateoncolumn()