CREATE TRIGGER setordercontainersupdate
BEFORE UPDATE ON order_containers
FOR EACH ROW EXECUTE PROCEDURE setupdateoncolumn()