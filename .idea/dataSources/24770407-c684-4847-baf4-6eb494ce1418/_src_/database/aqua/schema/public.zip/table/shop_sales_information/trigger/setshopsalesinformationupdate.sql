CREATE TRIGGER setshopsalesinformationupdate
BEFORE UPDATE ON shop_sales_information
FOR EACH ROW EXECUTE PROCEDURE setupdateoncolumn()