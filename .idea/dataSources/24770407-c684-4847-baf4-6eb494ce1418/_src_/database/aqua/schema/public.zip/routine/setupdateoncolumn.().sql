CREATE FUNCTION setupdateoncolumn () RETURNS trigger
	LANGUAGE plpgsql
AS $$
BEGIN
   NEW.updated_on = now(); 
   RETURN NEW;
END;
$$
