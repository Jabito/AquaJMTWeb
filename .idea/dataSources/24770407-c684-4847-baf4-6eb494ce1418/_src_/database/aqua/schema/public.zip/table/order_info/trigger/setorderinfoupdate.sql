CREATE TRIGGER setorderinfoupdate
BEFORE UPDATE ON order_info
FOR EACH ROW EXECUTE PROCEDURE setupdateoncolumn()