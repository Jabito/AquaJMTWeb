CREATE TRIGGER setcustomerloginupdate
BEFORE UPDATE ON customer_login
FOR EACH ROW EXECUTE PROCEDURE setupdateoncolumn()