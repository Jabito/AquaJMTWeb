CREATE TRIGGER setshopinfoupdate
BEFORE UPDATE ON shop_info
FOR EACH ROW EXECUTE PROCEDURE setupdateoncolumn()