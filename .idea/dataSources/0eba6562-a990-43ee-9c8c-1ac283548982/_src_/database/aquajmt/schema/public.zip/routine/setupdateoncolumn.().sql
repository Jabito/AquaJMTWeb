create function setupdateoncolumn() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
   NEW.updated_on = now(); 
   RETURN NEW;
END;
$$;
